PEP 257 plugin for py.test
=============

Minimal version of PEP 257 reports with py.test

Installation
============

Install with pip:

::

    pip install pytest-pep257

